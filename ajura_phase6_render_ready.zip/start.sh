#!/bin/bash
python3 src/backend/bot.py
