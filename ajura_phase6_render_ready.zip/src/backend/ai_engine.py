import openai

class AiEngine:
    def __init__(self, api_key):
        self.api_key = api_key

    def chat(self, prompt):
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "system", "content": "You are Ajura AI."}, {"role": "user", "content": prompt}],
            api_key=self.api_key
        )
        return response["choices"][0]["message"]["content"]
