import os
from ai_engine import AiEngine
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
AUTH_PASSWORD = os.getenv("AUTH_PASSWORD")

ai = AiEngine(OPENAI_API_KEY)

async def start(update: Update, context):
    await update.message.reply_text("Hello! Ajura is ready!")

app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.run_polling()
