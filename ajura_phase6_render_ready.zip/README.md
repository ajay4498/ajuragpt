# Ajura Phase 6 - Render Ready
This project contains the code for Ajura Phase 6, ready to be deployed on **Render**.

## Steps to Deploy:
1. **Upload all files to GitHub.**
2. **In Render, select "Public Git Repository"** and enter the GitHub repo URL.
3. **Manually add API keys** (`OPENAI_API_KEY`, `TELEGRAM_BOT_TOKEN`, `AUTH_PASSWORD`) in **Render Environment Settings**.
4. **Render will automatically install dependencies and start the bot!**

Enjoy using Ajura AI 🚀
